const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

// Konfigurasi Telegram
const TELEGRAM_TOKEN = 'ISI_TOKEN_BOT';
const TELEGRAM_CHAT_ID = 'ISI_CHAT_ID';

// Middleware Basic Auth untuk admin.html
app.use('/admin.html', (req, res, next) => {
    const auth = {login: 'admin', password: 'denzzstore123'};

    const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
    const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':');

    if (login && password && login === auth.login && password === auth.password) {
        return next();
    }
    res.set('WWW-Authenticate', 'Basic realm="Admin Area"');
    res.status(401).send('Authentication required.');
});

// Endpoint buat orderan
app.post('/api/order', async (req, res) => {
    const { name, service, number } = req.body;

    try {
        await axios.post(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
            chat_id: TELEGRAM_CHAT_ID,
            text: `📦 New Order:\n👤 Name: ${name}\n📱 Service: ${service}\n🔢 Number: ${number}`
        });

        res.send({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).send({ error: 'Failed to send order' });
    }
});

// Jalankan server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server berjalan di port ${PORT}`);
});
